#!/system/bin/sh

LOGFILE=/data/adb/cloakcalm_log.txt
GAMMA_PATH=/sys/devices/platform/1c2c0000.drmdsim/1c2c0000.drmdsim.0/gamma

log() {
  echo "$1 - $(date)" >> "$LOGFILE"
}

wait_for_gamma() {
  COUNT=0
  while [ ! -w "$GAMMA_PATH" ] && [ $COUNT -lt 10 ]; do
    sleep 1
    COUNT=$((COUNT + 1))
  done
}

case "$1" in
  on)
    wait_for_gamma
    if [ -w "$GAMMA_PATH" ]; then
      echo "200 150 120" > "$GAMMA_PATH"
      settings put system screen_brightness 100
      settings put system screen_off_timeout 300000
      settings put global sensors_off 1
      log "🧘 CloakCalm ON | gamma: 200 150 120"
    else
      log "❌ GAMMA write failed - device not ready"
    fi
    ;;
  off)
    wait_for_gamma
    if [ -w "$GAMMA_PATH" ]; then
      echo "255 255 255" > "$GAMMA_PATH"
      settings put global sensors_off 0
      log "🧘 CloakCalm OFF | gamma: 255 255 255"
    else
      log "❌ GAMMA reset failed - device not ready"
    fi
    ;;
  status)
    echo "🔍 CloakCalm Status"
    echo "Gamma: [write-only, current value unknown]"
    echo "Sensors off: $(settings get global sensors_off)"
    ;;
  set)
    if [ $# -eq 4 ]; then
      wait_for_gamma
      if [ -w "$GAMMA_PATH" ]; then
        echo "$2 $3 $4" > "$GAMMA_PATH"
        log "🎨 Custom gamma set to $2 $3 $4"
      else
        log "❌ GAMMA custom set failed - device not ready"
      fi
    else
      echo "Usage: cloakcalm set R G B"
    fi
    ;;
  *)
    echo "Usage: cloakcalm {on|off|status|set R G B}"
    ;;
esac
