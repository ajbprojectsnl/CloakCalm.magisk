#!/system/bin/sh
# CloakCalm post-fs setup
chmod 0664 /sys/devices/platform/1c2c0000.drmdsim/1c2c0000.drmdsim.0/gamma
sleep 5
sh /data/adb/modules/cloakcalm/service.sh on
